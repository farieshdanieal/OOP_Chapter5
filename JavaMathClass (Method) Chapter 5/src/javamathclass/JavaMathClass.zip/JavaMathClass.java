/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javamathclass;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class JavaMathClass {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int num1 = reader.nextInt();

        System.out.print("Enter second integer: ");
        int num2 = reader.nextInt();

        System.out.print("Enter third integer: ");
        int num3 = reader.nextInt();

        MaxNum myMax = new MaxNum();
        myMax.showmessage(num1, num2, num3);

        MinNum myMin = new MinNum();
        myMin.showoutput(num1, num2, num3);

        reader.close();
    }
}

