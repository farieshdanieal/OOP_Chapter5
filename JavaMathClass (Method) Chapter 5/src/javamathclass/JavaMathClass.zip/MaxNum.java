/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamathclass;

/**
 *
 * @author User
 */

public class MaxNum {
    public void showmessage(int num1, int num2, int num3) {
        int max = maximum(num1, num2, num3);
        System.out.println("Maximum value is: " + max);
    }

    public int maximum(int num1, int num2, int num3) {
        return Math.max(num1, Math.max(num2, num3));
    }
}

