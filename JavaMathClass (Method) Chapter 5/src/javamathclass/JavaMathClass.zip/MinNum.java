/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamathclass;

/**
 *
 * @author User
 */

public class MinNum {

    public void showoutput(int num1, int num2, int num3) {
        int min = minimum(num1, num2, num3);
        System.out.println("Minimum value is: " + min);
    }

    public int minimum(int num1, int num2, int num3) {
        return Math.min(num1, Math.min(num2, num3));
    }
}


